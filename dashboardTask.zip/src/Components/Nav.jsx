import logo from '../assets/TestLogo.svg'
import home from '../assets/home_FILL0_wght300_GRAD0_opsz24.svg'
import patiants from '../assets/group_FILL0_wght300_GRAD0_opsz24.svg'
import calender from '../assets/calendar_today_FILL0_wght300_GRAD0_opsz24.svg'
import message from '../assets/chat_bubble_FILL0_wght300_GRAD0_opsz24.svg'
import card from '../assets/credit_card_FILL0_wght300_GRAD0_opsz24.svg'
import person from '../assets/image.png'
import settings from '../assets/settings_FILL0_wght300_GRAD0_opsz24.svg'
import details from '../assets/more_vert_FILL0_wght300_GRAD0_opsz24.svg'
import { useState } from 'react'


export default function Nav() {
    const [selected, setSelected] = useState("Patiants")
    return (
        <div className='flex items-center justify-between m-[18px] h-[72px] bg-white rounded-[70px] px-[32px]'>
            <div className='flex items-center shrink-0 '>
                <img src={logo} alt="" />
            </div>
            <div className='flex items-center gap-4 transtion-all '>
                <button
                    onClick={(e) => setSelected(e.currentTarget.value)}
                    className={`flex items-center gap-2 body-bold hover:bg-primary rounded-full px-4 py-2 transtion-all duration-300 ${selected === "Overview" ? "bg-primary " : ""}`}>
                    <img src={home} alt="" />
                    Overview
                </button>
                <button
                    onClick={(e) => setSelected(e.currentTarget.value)}
                    className={`flex items-center gap-2 body-bold hover:bg-primary rounded-full px-4 py-2 transtion-all duration-300 ${selected === "Patients" ? "bg-primary " : ""}`}>
                    <img src={patiants} alt="" />
                    Patients
                </button>
                <button
                    onClick={(e) => setSelected(e.currentTarget.value)}
                    className={`flex items-center gap-2 body-bold hover:bg-primary rounded-full px-4 py-2 transtion-all duration-300 ${selected === "Schedule" ? "bg-primary " : ""}`}>
                    <img src={calender} alt="" />
                    Schedule
                </button>
                <button onClick={(e) => setSelected(e.currentTarget.value)}
                    className={`flex items-center gap-2 body-bold hover:bg-primary rounded-full px-4 py-2 transtion-all duration-300 ${selected === "Message" ? "bg-primary " : ""}`}>
                    <img src={message} alt="" />
                    Message
                </button>
                <button onClick={(e) => setSelected(e.currentTarget.value)}
                    className={`flex items-center gap-2 body-bold hover:bg-primary rounded-full px-4 py-2 transtion-all duration-300 ${selected === "Transactions" ? "bg-primary " : ""}`}>
                    <img src={card} alt="" />
                    Transactions
                </button>

            </div>
            <div className='flex gap-4 justify-end items-center'>
                <div className='h-[44px] w-[44px]'>
                    <img src={person} alt="" />
                </div>
                <div className='flex flex-col items-start' >
                    <p className='body-bold'>Dr. Jose Simmons</p>
                    <p className='body-secondary'>General Practitioner</p>
                </div>
                <div className="w-px h-8 bg-gray-200"></div>

                <div className='flex gap-4 '>
                    <img className='h-[20px]' src={settings} alt="" />
                    <img className='h-[20px]' src={details} alt="" />
                </div>
            </div>
        </div>
    )
}
